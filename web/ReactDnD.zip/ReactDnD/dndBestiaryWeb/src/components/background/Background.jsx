import style from './backgroundstyle.module.css'

function Background() {

    return (
      <div className={style.fon}>
      </div>
    )
  }
  
  export default Background